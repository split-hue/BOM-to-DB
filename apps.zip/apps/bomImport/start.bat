
::LOGS -> Spring Boot has built-in logging to file � `--logging.file.name` writes the normal app log (INFO, WARN, ERROR all go here), and `2>` redirects the raw stderr (JVM crashes, startup errors before Spring even boots) to a separate `error.log`.
::delete LOGS -> keeps one app.log that rolls over when it hits 10MB, keeps the last 30 rolled files, and never exceeds 200MB total. Old files are deleted automatically � no cleanup script needed, Spring handles it all.

@echo off

setlocal



:: App settings

set JAVA_HOME=C:\apps\bomImport\java21

set APP=C:\apps\bomImport\import_ksenija-1.0-SNAPSHOT.jar

set LOG_DIR=C:\apps\bomImport\logs



echo Using Java:

"%JAVA_HOME%\bin\java" -version



echo Starting app...

"%JAVA_HOME%\bin\java" -jar "%APP%" ^

    --server.port=8086 ^

    --logging.file.name="%LOG_DIR%\app.log" ^

    --logging.level.root=INFO ^

    --logging.logback.rollingpolicy.max-file-size=10MB ^

    --logging.logback.rollingpolicy.max-history=30 ^

    --logging.logback.rollingpolicy.total-size-cap=200MB ^

    2>"%LOG_DIR%\error.log"



endlocal