:: Finds and kills the java process running on port 8086


@echo off

:: Auto-elevate to admin
net session >nul 2>&1

if %errorlevel% neq 0 (

    powershell -Command "Start-Process '%~f0' -Verb RunAs"

    exit

)



:: Stop the app
for /f "tokens=5" %%a in ('netstat -aon ^| find ":8086"') do taskkill /F /PID %%a

echo App stopped.
pause
pause